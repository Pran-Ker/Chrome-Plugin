declare const browser: typeof chrome
